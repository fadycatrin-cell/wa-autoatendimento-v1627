# WA Autoatendimento V16.3.0 — Desbloqueio biométrico

Atualização baseada na V16.2.9, preservando o painel, categorias, sons, horários, respostas automáticas, nome e ícone.

## Alteração
- A tela de bloqueio mantém o PIN numérico de 6 dígitos.
- Quando o aparelho possui biometria cadastrada e disponível, mostra também a opção “Desbloquear com impressão digital”.
- A autenticação é feita pelo Android BiometricPrompt; o aplicativo não acessa nem armazena a impressão digital.
- O PIN permanece como alternativa se a biometria falhar ou não estiver disponível.

## Gerar APK
O projeto Android fica na raiz do ZIP. No GitHub Actions, execute o workflow `Gerar APK WA Autoatendimento`. O APK debug será publicado como artefato.
