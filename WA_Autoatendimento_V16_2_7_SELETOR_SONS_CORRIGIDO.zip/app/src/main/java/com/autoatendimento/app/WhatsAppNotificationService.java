package com.autoatendimento.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.os.Build;
import android.app.RemoteInput;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.media.MediaPlayer;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONObject;

public class WhatsAppNotificationService extends NotificationListenerService {
    private static final String WA = "com.whatsapp";
    private static final String WAB = "com.whatsapp.w4b";
    private static final String HISTORY_KEY = "history";
    private static final String STATE_KEY = "wa_automation_state_v13";
    private static final long DEDUPE_WINDOW_MS = 12000L;
    private static final long OUTGOING_IGNORE_MS = 30000L;
    private static final long PENDING_REPLY_WINDOW_MS = 120000L;
    private SharedPreferences prefs;
    private final Object lock = new Object();
    private final LinkedHashMap<String, Long> recentProcessed = new LinkedHashMap<>();
    private final LinkedHashMap<String, Long> recentOutgoing = new LinkedHashMap<>();

    @Override public void onCreate() { super.onCreate(); prefs = getSharedPreferences("auto_config", MODE_PRIVATE); }

    @Override public void onNotificationPosted(StatusBarNotification sbn) {
        if (!WA.equals(sbn.getPackageName()) && !WAB.equals(sbn.getPackageName())) return;
        Notification notification = sbn.getNotification();
        if (isGroupConversation(notification)) return;
        String text = extractText(notification);
        if (text.trim().isEmpty()) return;
        JSONObject cfg;
        try { cfg = new JSONObject(prefs.getString("config", "{}")); } catch(Exception e) { return; }
        if (!cfg.optBoolean("active", false)) return;
        String title = "";
        if (notification.extras != null) title = String.valueOf(notification.extras.getCharSequence(Notification.EXTRA_TITLE, ""));
        final long now = System.currentTimeMillis();
        final String normalizedText = norm(text);
        final String normalizedTitle = norm(title);
        synchronized (lock) {
            cleanup(recentOutgoing, now, OUTGOING_IGNORE_MS);
            if (recentOutgoing.containsKey(sbn.getPackageName() + "|" + normalizedText)) return;
            cleanup(recentProcessed, now, DEDUPE_WINDOW_MS);
            String k1 = sbn.getPackageName() + "|" + sbn.getKey() + "|" + normalizedText;
            String k2 = sbn.getPackageName() + "|" + normalizedTitle + "|" + normalizedText;
            if (recentProcessed.containsKey(k1) || recentProcessed.containsKey(k2)) return;
            recentProcessed.put(k1, now); recentProcessed.put(k2, now);
        }
        if (isBlockedPhone(title, cfg.optJSONArray("blockedPhones"))) return;
        String contactKey = sbn.getPackageName() + "|" + normalizedTitle;
        if (isQuestionMessage(text)) appendQuestionHistory(title, text);
        ReplyDecision decision = chooseReply(cfg, text, contactKey, now);
        if (decision == null || decision.reply == null || decision.reply.trim().isEmpty()) { if (!isLikelyOrder(text) && !hasExactConfiguredMatch(cfg, text)) playConfiguredSound("noanswer", cfg.optInt("noAnswerSoundId", 1), cfg.optInt("noAnswerSoundVolume", 35), 2); return; }
        final String reply = decision.reply;
        final int delaySeconds = Math.max(0, Math.min(60, cfg.optInt("replyDelaySeconds", 0)));
        final String contact = title;
        final String contactTitle = title;
        final String originalText = text;
        final String packageName = sbn.getPackageName();
        Runnable sendTask = () -> {
            boolean sent = sendReply(notification, reply);
            if (sent) {
                synchronized (lock) { recentOutgoing.put(packageName + "|" + norm(reply), System.currentTimeMillis()); }
                if (decision.importantAlert) postImportantNotification(contactTitle, originalText, cfg.optInt("importantSoundVolume", 90), cfg.optInt("importantSoundId", 1));
                else if (cfg.optBoolean("soundEnabled", true)) playConfiguredSound("response", cfg.optInt("soundId", 1), cfg.optInt("soundVolume", 70), 2);
                markSent(contactKey, decision, System.currentTimeMillis());
            } else {
                clearPending(contactKey, decision);
            }
            appendHistory(contact, originalText, sent ? reply : "Não foi possível enviar automaticamente pela notificação.", sent, delaySeconds, decision.reason);
        };
        if (delaySeconds > 0) new Handler(Looper.getMainLooper()).postDelayed(sendTask, delaySeconds * 1000L); else sendTask.run();
    }

    private boolean hasExactConfiguredMatch(JSONObject cfg, String incoming) {
        String n=norm(incoming); JSONArray categories=cfg.optJSONArray("categories"); if(n.isEmpty()||categories==null)return false;
        for(int i=0;i<categories.length();i++){JSONObject cat=categories.optJSONObject(i);if(cat==null||!cat.optBoolean("enabled",true))continue;JSONArray groups=cat.optJSONArray("groups");if(groups==null)continue;
            for(int j=0;j<groups.length();j++){JSONObject group=groups.optJSONObject(j);if(group==null||!group.optBoolean("enabled",true))continue;JSONArray questions=group.optJSONArray("questions");if(questions==null)continue;
                for(int k=0;k<questions.length();k++)if(n.equals(norm(questions.optString(k))))return true;
            }
        }return false;
    }

    private boolean isBlockedPhone(String title, JSONArray blocked) {
        if (blocked == null || title == null) return false;
        String digits = title.replaceAll("\\D", "");
        if (digits.isEmpty()) return false;
        for (int i = 0; i < blocked.length(); i++) {
            String value = blocked.optString(i, "").replaceAll("\\D", "");
            if (!value.isEmpty() && (digits.equals(value) || digits.endsWith(value) || value.endsWith(digits))) return true;
        }
        return false;
    }

    private static class ReplyDecision {
        String reply, categoryId, groupId, reason;
        boolean welcome, afterHours, importantAlert;
        ReplyDecision(String r, String c, String g, String why, boolean w, boolean a) { reply=r; categoryId=c; groupId=g; reason=why; welcome=w; afterHours=a; importantAlert=false; }
    }

    private synchronized ReplyDecision chooseReply(JSONObject c, String msg, String contact, long now) {
        boolean openNow = isOpenNow(c.optJSONObject("schedule"));
        JSONObject state = readState();
        JSONObject cs = state.optJSONObject(contact);
        if (cs == null) cs = new JSONObject();
        // Fora do horário: envia o aviso inicial apenas quando o intervalo venceu.
        // Nas mensagens seguintes, continua procurando respostas nas categorias,
        // sem repetir o aviso a cada mensagem e respeitando os intervalos dos grupos.
        if (!openNow && c.optBoolean("afterHoursEnabled", true)) {
            long lastAfterHours = cs.optLong("afterHoursAt", 0L);
            long pendingAfterHours = cs.optLong("pendingAfterHoursAt", 0L);
            long intervalMs = Math.max(1, Math.min(10080, c.optInt("afterHoursIntervalMinutes", 360))) * 60000L;
            boolean pending = pendingAfterHours > 0L && now - pendingAfterHours < PENDING_REPLY_WINDOW_MS;
            boolean intervalActive = lastAfterHours > 0L && now - lastAfterHours < intervalMs;
            if (!pending && !intervalActive) {
                try { cs.put("pendingAfterHoursAt", now); state.put(contact, cs); writeState(state); } catch(Exception ignored) {}
                return new ReplyDecision(c.optString("afterHours", "Olá! No momento estamos fora do nosso horário de funcionamento."), "", "", "Mensagem fora do horário", false, true);
            }
        }
        if (isLikelyOrder(msg)) return null;
        String n = norm(msg);
        // Boas-vindas tem prioridade quando o restaurante está aberto e seu
        // intervalo independente venceu. Não depende do texto ser uma saudação.
        if (openNow && c.optBoolean("welcomeEnabled", false)) {
            long lastWelcome = cs.optLong("welcomeAt", 0L);
            long pendingWelcome = cs.optLong("pendingWelcomeAt", 0L);
            if (pendingWelcome > 0L && now - pendingWelcome < PENDING_REPLY_WINDOW_MS) return null;
            long welcomeIntervalMs = Math.max(1, Math.min(10080,
                c.optInt("welcomeIntervalMinutes",
                    Math.max(1, c.optInt("welcomeIntervalHours", 6)) * 60))) * 60000L;
            if (lastWelcome == 0L || now - lastWelcome >= welcomeIntervalMs) {
                try {
                    cs.put("pendingWelcomeAt", now);
                    state.put(contact, cs);
                    writeState(state);
                } catch(Exception ignored) {}
                String welcomeReply = c.optString("welcome", "");
                if (!welcomeReply.trim().isEmpty()) {
                    return new ReplyDecision(welcomeReply, "", "", "Boas-vindas", true, false);
                }
            }
        }
        if (isLikelyOrder(msg)) return null;
        // O intervalo das categorias e contado desde a ultima resposta ENVIADA,
        // e nao desde a ultima mensagem recebida. Assim, mensagens repetidas
        // nao reiniciam o prazo e nao bloqueiam indefinidamente a automacao.
        JSONArray categories = c.optJSONArray("categories");
        JSONObject responded = cs.optJSONObject("respondedGroups");
        if (responded == null) responded = new JSONObject();
        try { cs.put("respondedGroups", responded); } catch(Exception ignored) {}
        if (categories != null) {
            for (int i=0; i<categories.length(); i++) {
                JSONObject cat = categories.optJSONObject(i); if (cat == null || !cat.optBoolean("enabled", true)) continue;
                String cid = cat.optString("id", "cat_"+i);
                JSONObject catResponded = responded.optJSONObject(cid);
                if (catResponded == null) catResponded = new JSONObject();
                long idleMs = Math.max(1, Math.min(10080, cat.optInt("inactivityMinutes", 30))) * 60000L;
                JSONArray groups = cat.optJSONArray("groups"); if (groups == null) continue;
                for (int j=0; j<groups.length(); j++) {
                    JSONObject group = groups.optJSONObject(j); if (group == null || !group.optBoolean("enabled", true)) continue;
                    String gid = group.optString("id", "grp_"+j);
                    long lastSent = catResponded.optLong(gid, 0L);
                    // Compatibilidade: estado antigo booleano nao possui timestamp; libera-o.
                    if (lastSent > 0L && now - lastSent < idleMs) continue;
                    if (lastSent > 0L) catResponded.remove(gid);
                    JSONArray questions = group.optJSONArray("questions"); if (questions == null) continue;
                    boolean matched = false;
                    for (int q=0; q<questions.length(); q++) {
                        String question = norm(questions.optString(q));
                        if (!question.isEmpty() && question.equals(n)) { matched = true; break; }
                    }
                    if (matched) {
                        try { responded.put(cid, catResponded); cs.put("respondedGroups", responded); state.put(contact, cs); writeState(state); } catch(Exception ignored) {}
                        ReplyDecision decision = new ReplyDecision(group.optString("reply", ""), cid, gid, "Categoria: "+cat.optString("name", "")+" / "+group.optString("name", ""), false, false); decision.importantAlert = cat.optBoolean("alertEnabled", false); return decision;
                    }
                }
                try { responded.put(cid, catResponded); } catch(Exception ignored) {}
            }
        }
        try { state.put(contact, cs); writeState(state); } catch(Exception ignored) {}
        return null;
    }

    private void markSent(String contact, ReplyDecision d, long now) {
        synchronized(lock) {
            JSONObject state = readState(); JSONObject cs = state.optJSONObject(contact); if (cs == null) cs = new JSONObject();
            try {
                if (d.welcome) { cs.put("welcomeAt", cs.optLong("pendingWelcomeAt", now)); cs.remove("pendingWelcomeAt"); }
                else if (d.afterHours) { cs.put("afterHoursAt", cs.optLong("pendingAfterHoursAt", now)); cs.remove("pendingAfterHoursAt"); }
                else if (d.categoryId != null && !d.categoryId.isEmpty()) {
                    JSONObject responded = cs.optJSONObject("respondedGroups"); if (responded == null) responded = new JSONObject();
                    JSONObject cat = responded.optJSONObject(d.categoryId); if (cat == null) cat = new JSONObject();
                    // Guarda o instante da resposta enviada; o intervalo nao reinicia
                    // quando o cliente manda mensagens adicionais durante o bloqueio.
                    cat.put(d.groupId, now); responded.put(d.categoryId, cat); cs.put("respondedGroups", responded);
                }
                state.put(contact, cs); writeState(state);
            } catch(Exception ignored) {}
        }
    }

    private void clearPending(String contact, ReplyDecision d) {
        synchronized (lock) {
            JSONObject state = readState();
            JSONObject cs = state.optJSONObject(contact);
            if (cs == null) return;
            try {
                if (d.welcome) cs.remove("pendingWelcomeAt");
                else if (d.afterHours) cs.remove("pendingAfterHoursAt");
                state.put(contact, cs);
                writeState(state);
            } catch (Exception ignored) {}
        }
    }

    private JSONObject readState() { try { return new JSONObject(prefs.getString(STATE_KEY, "{}")); } catch(Exception e) { return new JSONObject(); } }
    private void writeState(JSONObject state) {
        try {
            // Limita o armazenamento a 500 contatos, eliminando os mais antigos pela ordem de iteração.
            if (state.length() > 500) { ArrayList<String> keys = new ArrayList<>(); Iterator<String> it = state.keys(); while (it.hasNext()) keys.add(it.next()); for (int i=0; i<keys.size() && state.length()>500; i++) state.remove(keys.get(i)); }
            prefs.edit().putString(STATE_KEY, state.toString()).apply();
        } catch(Exception ignored) {}
    }

    private boolean isGreeting(String n) { return n.matches("(oi|ola|oie|bom dia|boa tarde|boa noite|hello|hey|ola tudo bem|oi tudo bem)"); }
    private boolean isLikelyOrder(String s) {
        String n = norm(s); String[] lines = s.split("\\n");
        int nonempty=0; for(String line:lines) if(!line.trim().isEmpty()) nonempty++;
        boolean money = s.matches("(?s).*(R\\$\\s?\\d|total\\s*:?|subtotal|pedido\\s*(n[ºo.]|realizado|confirmado)?).*" );
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("\\b\\d+\\s?(x|un|unid|unidade|porcao)?\\b", java.util.regex.Pattern.CASE_INSENSITIVE).matcher(s); int quantities=0; while(m.find()) quantities++;
        boolean address = n.matches("(?s).*(rua|avenida|av|bairro|apto|apartamento|entregar em|casa \\d+).*" );
        return (money && (quantities>=2 || nonempty>=3)) || (quantities>=3 && nonempty>=2) || (address && quantities>=2) || (n.matches("(?s).*(meu pedido|resumo do pedido|pedido realizado).*" ) && s.length()>60);
    }
    private String semanticKey(String value) {
        String[] words = norm(value).split(" ");
        java.util.Set<String> ignored = new java.util.HashSet<>(java.util.Arrays.asList(
            "voces","voce","tem","hoje","amanha","ontem","ai","por","favor","gostaria","queria","saber",
            "me","diz","diga","pode","podem","poderia","poderiam","meu","minha","seu","sua","um","uma",
            "o","a","os","as","de","do","da","dos","das","no","na","nos","nas","para","pra","com","que",
            "qual","quais","como","e","esta","estao","teria","teriam","vcs"));
        StringBuilder out = new StringBuilder();
        for (String word : words) if (!word.isEmpty() && !ignored.contains(word)) {
            if (out.length() > 0) out.append(' ');
            out.append(word);
        }
        return out.toString();
    }
    private boolean semanticOverlap(String a, String b) {
        String[] aa=semanticKey(a).split(" "), bb=semanticKey(b).split(" ");
        java.util.Set<String> x=new java.util.HashSet<>(), y=new java.util.HashSet<>();
        for(String w:aa) if(!w.isEmpty()) x.add(w);
        for(String w:bb) if(!w.isEmpty()) y.add(w);
        if(x.isEmpty()||y.isEmpty()) return false;
        int common=0; for(String w:x) if(y.contains(w)) common++;
        return (common>=2 && ((double)common/Math.min(x.size(),y.size()))>=0.72)
            || (x.size()==1 && y.size()==1 && x.iterator().next().equals(y.iterator().next()) && x.iterator().next().length()>=6);
    }
    private boolean safeNearMatch(String a, String b) {
        if (a == null || b == null || Math.min(a.length(), b.length()) < 12) return false;
        String[] aa=a.split(" "), bb=b.split(" "); if (Math.abs(aa.length-bb.length)>1) return false;
        return (double)editDistance(a,b)/Math.max(a.length(),b.length()) <= 0.08;
    }
    private int editDistance(String a,String b) {
        int[][] d=new int[a.length()+1][b.length()+1]; for(int i=0;i<=a.length();i++)d[i][0]=i; for(int j=0;j<=b.length();j++)d[0][j]=j;
        for(int i=1;i<=a.length();i++)for(int j=1;j<=b.length();j++)d[i][j]=Math.min(Math.min(d[i-1][j]+1,d[i][j-1]+1),d[i-1][j-1]+(a.charAt(i-1)==b.charAt(j-1)?0:1)); return d[a.length()][b.length()];
    }
    private boolean isGroupConversation(Notification n) { try { Bundle e=n.extras; return e!=null && e.getBoolean("android.isGroupConversation", false); } catch(Exception ignored) { return false; } }
    private String extractText(Notification n) {
        Bundle e=n.extras; if(e==null)return ""; CharSequence cs=e.getCharSequence(Notification.EXTRA_BIG_TEXT); if(cs==null)cs=e.getCharSequence(Notification.EXTRA_TEXT);
        if(cs==null){CharSequence[] lines=e.getCharSequenceArray(Notification.EXTRA_TEXT_LINES);if(lines!=null&&lines.length>0){StringBuilder b=new StringBuilder();for(CharSequence line:lines)if(line!=null){if(b.length()>0)b.append("\\n");b.append(line);}cs=b.toString();}}
        return cs==null?"":cs.toString();
    }
    private boolean isOpenNow(JSONObject schedule) {
        java.util.Calendar cal=java.util.Calendar.getInstance();
        int mins=cal.get(java.util.Calendar.HOUR_OF_DAY)*60+cal.get(java.util.Calendar.MINUTE);
        if(schedule==null)return true;
        String[] days={"domingo","segunda","terca","quarta","quinta","sexta","sabado"};
        int day=cal.get(java.util.Calendar.DAY_OF_WEEK)-1; JSONArray periods=schedule.optJSONArray(days[day]); if(periods==null||periods.length()==0)return false;
        for(int i=0;i<periods.length();i++)try{JSONArray p=periods.getJSONArray(i);int a=toMin(p.getString(0)),b=toMin(p.getString(1));if(b<=a?(mins>=a||mins<b):(mins>=a&&mins<b))return true;}catch(Exception ignored){} return false;
    }
    private int toMin(String s){String[] x=s.split(":");return Integer.parseInt(x[0])*60+Integer.parseInt(x[1]);}
    private String norm(String s) { return Normalizer.normalize(s==null?"":s,Normalizer.Form.NFD).replaceAll("\\p{M}","").toLowerCase(Locale.ROOT).replaceAll("[!?.,;:¿¡]+"," ").replaceAll("[^\\p{L}\\p{N}\\s]"," ").replaceAll("\\s+"," ").trim(); }
    private boolean sendReply(Notification n,String reply){if(n.actions==null)return false;for(Notification.Action a:n.actions){RemoteInput[] ris=a.getRemoteInputs();if(ris==null||ris.length==0)continue;Intent intent=new Intent();Bundle results=new Bundle();for(RemoteInput ri:ris)results.putCharSequence(ri.getResultKey(),reply);RemoteInput.addResultsToIntent(ris,intent,results);try{a.actionIntent.send(this,0,intent);return true;}catch(Exception ignored){}}return false;}
    private void cleanup(Map<String,Long> map,long now,long ttl){Iterator<Map.Entry<String,Long>> it=map.entrySet().iterator();while(it.hasNext())if(now-it.next().getValue()>=ttl)it.remove();}
    private void playNoAnswerSound(int soundId, int volume) { playToneResource(soundResource(Math.max(1, Math.min(10, soundId))), volume, 2); }
    private void playConfiguredSound(String category, int soundId, int volume, int repeats) {
        String uri = getSharedPreferences("auto_config", MODE_PRIVATE).getString("ringtone_" + category, "");
        if (uri == null || uri.isEmpty()) {
            if ("important".equals(category)) playImportantSound(soundId, volume);
            else if ("noanswer".equals(category)) playNoAnswerSound(soundId, volume);
            else playResponseSound(soundId, volume);
            return;
        }
        playUriRepeated(android.net.Uri.parse(uri), volume, repeats);
    }
    private void playUriRepeated(android.net.Uri uri, int volume, int repeats) {
        try {
            final float v=Math.max(0f,Math.min(1f,volume/100f)); if(v<=0f)return;
            final MediaPlayer mp=new MediaPlayer();
            if(Build.VERSION.SDK_INT>=21) mp.setAudioAttributes(new android.media.AudioAttributes.Builder().setUsage(android.media.AudioAttributes.USAGE_NOTIFICATION).setContentType(android.media.AudioAttributes.CONTENT_TYPE_SONIFICATION).build());
            mp.setDataSource(this, uri);
            mp.setOnPreparedListener(player->{player.setVolume(v,v);final int[] count={0};player.setOnCompletionListener(done->{count[0]++;if(count[0]<Math.max(1,repeats)){try{done.seekTo(0);done.start();}catch(Exception e){try{done.release();}catch(Exception ignored){}}}else try{done.release();}catch(Exception ignored){}});player.start();});
            mp.setOnErrorListener((player,what,extra)->{try{player.release();}catch(Exception ignored){}return true;}); mp.prepareAsync();
        } catch(Exception ignored) {}
    }
    private void playImportantSound(int soundId, int volume) { playToneResource(soundResource(15 + Math.max(1, Math.min(10, soundId))), volume, 3); }
    private void playToneResource(int resId, int volume, int repeats) {
        try {
            float v=Math.max(0f,Math.min(1f,volume/100f)); if(v<=0f)return;
            MediaPlayer mp=MediaPlayer.create(this,resId); if(mp==null)return;
            if(Build.VERSION.SDK_INT>=21) mp.setAudioAttributes(new android.media.AudioAttributes.Builder().setUsage(android.media.AudioAttributes.USAGE_ALARM).setContentType(android.media.AudioAttributes.CONTENT_TYPE_SONIFICATION).build());
            else mp.setAudioStreamType(android.media.AudioManager.STREAM_ALARM);
            mp.setVolume(v,v); final int[] count={0};
            mp.setOnCompletionListener(player->{count[0]++;if(count[0]<Math.max(1,repeats)){try{player.seekTo(0);player.start();}catch(Exception e){try{player.release();}catch(Exception ignored){}}}else try{player.release();}catch(Exception ignored){}});
            mp.setOnErrorListener((player,what,extra)->{try{player.release();}catch(Exception ignored){}return true;}); mp.start();
        } catch(Exception ignored) {}
    }
    private void postImportantNotification(String contact, String incoming, int volume, int soundId) {
        try {
            NotificationManager nm=(NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE); if(nm==null)return;
            String channelId="wa_important_attention_v1";
            if(Build.VERSION.SDK_INT>=26){NotificationChannel ch=new NotificationChannel(channelId,"Alertas importantes do WA",NotificationManager.IMPORTANCE_HIGH);ch.setDescription("Mensagens que precisam de atenção");ch.setSound(null,null);nm.createNotificationChannel(ch);}
            Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,channelId):new Notification.Builder(this);
            b.setSmallIcon(R.drawable.icon_192).setContentTitle("Uma mensagem precisa atenção").setContentText((contact==null||contact.trim().isEmpty()?"Cliente":contact)+": "+(incoming==null?"":incoming)).setStyle(new Notification.BigTextStyle().bigText((contact==null||contact.trim().isEmpty()?"Cliente":contact)+" enviou: "+(incoming==null?"":incoming))).setAutoCancel(true).setPriority(Notification.PRIORITY_HIGH).setCategory(Notification.CATEGORY_MESSAGE);
            nm.notify((int)(System.currentTimeMillis()&0x7fffffff),b.build()); playConfiguredSound("important", soundId, volume, 3);
        } catch(SecurityException ignored) {} catch(Exception ignored) {}
    }
    public void testNoAnswerSoundForPanel(int soundId, int volume) { playNoAnswerSound(soundId, volume); }

    private int soundResource(int soundId) { switch(soundId) {case 1: return R.raw.alerta1;case 2: return R.raw.alerta2;case 3: return R.raw.alerta3;case 4: return R.raw.alerta4;case 5: return R.raw.alerta5;case 6: return R.raw.alerta6;case 7: return R.raw.alerta7;case 8: return R.raw.alerta8;case 9: return R.raw.alerta9;case 10: return R.raw.alerta10;case 11: return R.raw.alerta11;case 12: return R.raw.alerta12;case 13: return R.raw.alerta13;case 14: return R.raw.alerta14;case 15: return R.raw.alerta15;case 16: return R.raw.alerta16;case 17: return R.raw.alerta17;case 18: return R.raw.alerta18;case 19: return R.raw.alerta19;case 20: return R.raw.alerta20;case 21: return R.raw.alerta21;case 22: return R.raw.alerta22;case 23: return R.raw.alerta23;case 24: return R.raw.alerta24;case 25: return R.raw.alerta25;case 26: return R.raw.alerta26;case 27: return R.raw.alerta27;case 28: return R.raw.alerta28;case 29: return R.raw.alerta29;case 30: return R.raw.alerta30;case 31: return R.raw.alerta31;case 32: return R.raw.alerta32;case 33: return R.raw.alerta33;case 34: return R.raw.alerta34;case 35: return R.raw.alerta35;case 36: return R.raw.alerta36;case 37: return R.raw.alerta37;case 38: return R.raw.alerta38;case 39: return R.raw.alerta39;case 40: return R.raw.alerta40;case 41: return R.raw.alerta41;case 42: return R.raw.alerta42;case 43: return R.raw.alerta43;case 44: return R.raw.alerta44;case 45: return R.raw.alerta45;default: return R.raw.alerta1;} }
    private void playResponseSound(int soundId,int volume){playToneResource(soundResource(Math.max(1,Math.min(10,soundId))),volume,2);}
    private boolean isQuestionMessage(String text) {
        String raw = text == null ? "" : text.trim();
        if (raw.isEmpty() || raw.length() > 500) return false;
        if (raw.contains("?") || raw.contains("¿") || raw.contains("؟")) return true;
        String n = norm(raw);
        return n.matches("(?s)^(voces|voce|tem|qual|quais|quanto|quantos|quantas|como|onde|quando|porque|por que|pode|podem|faz|fazem|aceita|aceitam|consigo|gostaria|queria|me manda|me envia|tem como|queria saber|gostaria de saber|pode me informar|me informa|me diz|quero saber|esta|estao|is|are|do|does|what|when|where|how|can|could|cuanto|cuantos|cuantas|donde|hacen|tienen|puedo|quel|quelle|quels|quelles|combien|comment|pouvez vous)([ ]|$).*");
    }
    private void appendQuestionHistory(String contact, String incoming) {
        synchronized (lock) {
            try {
                JSONArray old = new JSONArray(prefs.getString(HISTORY_KEY, "[]"));
                JSONArray out = new JSONArray();
                JSONObject item = new JSONObject(); item.put("type", "pergunta");
                item.put("contact", contact == null ? "" : contact);
                item.put("incoming", incoming == null ? "" : incoming);
                item.put("at", new java.text.SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.getDefault()).format(new java.util.Date()));
                out.put(item);
                for (int i = 0; i < Math.min(old.length(), 299); i++) out.put(old.get(i));
                prefs.edit().putString(HISTORY_KEY, out.toString()).apply();
            } catch (Exception ignored) { }
        }
    }
    private void appendHistory(String contact,String incoming,String reply,boolean sent,int delaySeconds,String reason){synchronized(lock){try{JSONArray old=new JSONArray(prefs.getString(HISTORY_KEY,"[]"));JSONArray out=new JSONArray();JSONObject item=new JSONObject();item.put("type","atendimento");item.put("contact",contact==null?"":contact);item.put("incoming",incoming==null?"":incoming);item.put("reply",reply==null?"":reply);item.put("sent",sent);item.put("reason",reason==null?"":reason);item.put("delaySeconds",delaySeconds);item.put("at",new java.text.SimpleDateFormat("dd/MM/yyyy HH:mm:ss",Locale.getDefault()).format(new java.util.Date()));out.put(item);for(int i=0;i<Math.min(old.length(),299);i++)out.put(old.get(i));prefs.edit().putString(HISTORY_KEY,out.toString()).apply();}catch(Exception ignored){}}}
}
